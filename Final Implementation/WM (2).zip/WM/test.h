extern "C" {  // this is needed to make C++ and C work together
  #include "gpio_setup.h"
}
#include "device_layer.h"
// define a delay in milliseconds to be used between the blinking of LEDs
#define DELAY 1000


class Button {
  private:
	  uint16_t buttonPin; // Member that holds the bit location of the button on port E.
	  volatile uint32_t* buttonPort;// Member that holds the bit locations of the port the button is connected to.
	
	  // Methods
		static void latchAll(); // latches ALL buttons linked to switch reset.
		static void unlatchAll(); // unlatches ALL buttons linked to switch reset.
	public:
		// Non-default Constructor
	  // Defines the bit location of the button on Port E and resets ALL the latched buttons.
	  // Note it is also the default constructor since parameter has default value.
		Button(volatile uint32_t* GPIOx_IDR, uint16_t GPIO_Pin) {
			buttonPin = GPIO_Pin;
			buttonPort = GPIOx_IDR;
			
			resetAll();
		}
		
		// Methods
		static void resetAll(); // reset the button latches.
		bool isOn() {return ((*buttonPort) & buttonPin);} // returns the status of the button (on or off).
		
		
		Button object
		object.isOn
};

