**
 ******************************************************************************
 * File Name          : WM.cpp
 * Description        : Application to demonstrate interaction with the
 *                      washing machine simulator
 ******************************************************************************
 **/

/* 
  washing machine outputs (ports C and D)
  ---------------------------------------
  0x0040 PC6  Buzzer		
  0x0100 PD8  7 segment display bit A
  0x0400 PD10 7 segment display bit C
  0x0800 PD11 7 segment display bit B
  0x1000 PD12 motor control	
  0x2000 PD13 7 segment display bit D
  0x4000 PD14 reset latches
  0x8000 PD15 motor direction

  washing machine inputs (port E)
  -------------------------------
  0x0100 PE8  programme select 1
  0x0200 PE9  programme select 2
  0x0400 PE10 programme select 3
  0x0800 PE11 door open/close
  0x1000 PE12 accept button
  0x2000 PE13 cancel button
  0x8000 PE15 motor speed feedback
*/

 /*
 * Configuration of the STM32 Discovery board
 */
extern "C" {  // this is needed to make C++ and C work together
  #include "gpio_setup.h"
}
#include "device_layer.h"
#include "Timer.h"
// define a delay in milliseconds to be used between the blinking of LEDs
#define DELAY 1000


	// Instances of objects created for motor inputs
	MOTOR turner;
	SEVENSEG change;
	BUTTONS Hardreset; 
	MOTOR isTurning;
	DOOR opener;
	BUZZER buzzing;
	BUTTONS acceptor;
	TIMER time;

//-------------------------------------------------------------------------------------
//Door code
bool Doorstatus()
{
	return opener.isOpen();
}

//-------------------------------------------------------------------------------------
//MACHINE FUNCTIONS
//Turn on motor and begin spining in what direction
void startwash()
{
	turner.motor_on();
	time.begin();
}
//pause the wash and timer
void pausewash()
{
	turner.motor_off();
	time.pause();
}
//Reset timer to 0 and start wash from begining 
void resetwash()
{
	turner.motor_off();
	time.pause();
}
//start up the wash again
void resumewash()
{
	turner.motor_on();
	time.resume();
}
//buzz the alarm
void alarmon()
{
	buzzing.buzz_on();
	HAL_Delay(500);
	buzzing.buzz_off();
}

// 7 Segment Display 

void sevensegment() {

	change.seven_seg_set(int num)
}


// Button interface for the washing machine board

void 
