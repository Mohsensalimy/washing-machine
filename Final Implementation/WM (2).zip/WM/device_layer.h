/**
 ******************************************************************************
 * File Name          : device_layer.cpp
 * Description        : Source file containing functions for the device drivers
 ******************************************************************************
 **/
 
 extern "C" {  // this is needed to make C++ and C work together
  #include "gpio_setup.h"
}
 
#include "hardwarelayer_map.h"
#include "stdint.h"


#define CLKWISE 1
#define ANTI_CLKWISE 0
#define SELC 1
#define OPEN 1


//========  BUZZER CLASS  ==========///
class BUZZER {
	private:
	public: 
		
		//Methods
			void buzz_on();			//memebr function for turning on the buzzer
			void buzz_off();		//member function for turning the buzzer on
	//Might want to include default constructor for turing off the buzzer.
};


//========  MOTOR CLASS  ==========///
class MOTOR {
	private:
	public:
			void motor_on();	//memeber funbction for turning motor on
			void motor_off();	//memeber function for turning m0otor off
			void motor_turn(const int);		//memeber func to change direction of motor eg: clockwise and anti-clockwise

};	

//======== BUTTONS CLASS  ==========///
class BUTTONS {
	private:
//			static void latcher(); //Latches all Buttons linked to reset switch
//			static void resetlatch(); //unlatches buttons linked to the switch reset
	public:
			void resetInputLatch();	
			void lowResetSwitch();		
			void accept();
			void cancel();
			void left( const int);
			void middle(const int);
			void right(const int);
			void latcher();
			void resetlatch();
			bool Check(const int);
			bool glphy;
};



class DOOR {
	public:
		
	//Behavior
															//memeber function to close door
															//bool data type for door open/close because this memer will be returninig a function for what to do when door is close or open
				bool isOpen(); 		
				bool port;
};


//========  7 SEGMENT DISPLAY CLASS  ==========///
class SEVENSEG {
	private:
		//uint8_t to_printl;
	public:
		//behavior
			void seven_seg_set(const int);	//seven seg member function
};
