/**
 ******************************************************************************
 * File Name          : Timer.cpp
 * Description        : Timer class for washing machine operations
 ******************************************************************************
 **/
 
 extern "C" {  // this is needed to make C++ and C work together
  #include "gpio_setup.h"
};
 

//#include "device_layer.h"
#define DELAY 1000

int main(void) {
	
	TIM3 -> PSC = 100; //prescalor value in Timer 3 as 100
	TIM3 -> ARR = 1000;	//Auto-Reset Register of timer 3 set to 1000 counts
	TIM3 -> CR1 |= TIM_CR1_CEN;
	

//void TIM3_IRQHandler()
//	{
//	if ((TIM3->SR & TIM_SR_UIF) !=0) // Check interrupt source is from the �Update� interrupt flag
//	{

//	}
//	TIM3->SR &= ~TIM_SR_UIF; // Reset �Update� interrupt flag in the SR register
//	}
}