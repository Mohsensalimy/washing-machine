/**
 ******************************************************************************
 * File Name          : device_layer.cpp
 * Description        : Source file containing functions for the device drivers
 ******************************************************************************
 **/
 
 extern "C" {  // this is needed to make C++ and C work together
  #include "gpio_setup.h"
}
 
#define RUNNING 1
#define HALT 0


//======== TIMER CLASS  ==========///----- Sets Duration and checks if timer is done

class Timer {
	
	private:
					 bool status;  //checks if the timer is running or paused (halt)
					 bool countDownDone; // has countdown timer reached 0
					
	
//Variables which hold the time values (milliseconds)
					unsigned int duration;
					unsigned long TimerStart_id , TimerPauseCont, TimerPauseDiscont; 				// Overall time - When time started, how long paused & how long unpaused
					unsigned int TimerPauseDura , TimeRemain; 					// Total tme pasued and timer remainig till countdown has finished 
	
					unsigned long millisecs() {return HAL_GetTick()};
					
					
// function to reset the timer 
					void reset_timer(){
					status = HALT;
					countDownDone = false;			
					TimerPauseDura = 0;
					}
								
	public:
		
	
//default constructor 
				 timer(){
					reset_timer();
					duration = 0;
				 }
			
// Function to set the duration the timer counts down for in millisecodns
				 
				 void TimingSet_Milli (int milliseconds) {
					 duration = milliseconds;
				 }

// Function to set current time as the starting time for then on
				 
				 void begin {
				 reset();				//reinitialise current state of the timer
				 TimerStart_id = millisecs();
				 status = RUNNING;
				 }
				 
// Function which pauses the timer if the timer is still counting down and still has time remaining
				 
				 
				 void pause () {
				 if ((status == RUNNING) && (!countDownDone)){
							TimerPauseCont = millisecs();
							status = HALT;
						}		 
				 }
// Function to unpause from the last pause. (Resume Timer from previous pause)
				 
				 void resume () {
				 if (status == HALT) {
					 
							TimerPauseDiscont = millisecs();
							TimerPauseDura += TimerPauseDiscont - TimerPauseCont;
							status = RUNNING;
						}
				 }
				 
// Shows how long is remaining till the timer reaches the end of it's countdown
				
				 unsigned int timeLeft_ms() {
				 if (state == HALT) {
					return TimeRemain;
				}else {
						int countDownDuration = millisecs() - TimerPauseCont - TimerPauseDiscont;
						TimeRemain = duration - countDownDuration;
						return TimeRemain;
				
				}
	
		 }
				 
// Updates and returns status of the time ( when the timer has reached 0)			 
				 bool Timer_Finished () {
							getTimeLeft_ms();
							countDownDone = (TimeRemain <= 0);
							return countDownDone;

				 }
	
}