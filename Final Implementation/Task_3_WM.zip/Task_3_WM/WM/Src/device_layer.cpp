/**
 ******************************************************************************
 * File Name          : device_layer.cpp
 * Description        : Source file containing functions for the device drivers
 ******************************************************************************
 **/
 
 extern "C" {  // this is needed to make C++ and C work together
  #include "gpio_setup.h"
//	#include "device_layer.h"
};
 
#include "device_layer.h"
#define DELAY 1000




//==================== BUZZER_ON/OFF  =============//
void BUZZER::buzz_on() {
	washMach_BUZZER_PRT_REG |= (uint16_t) washMach_BUZZER; //function to turn the buzzer on
};

void BUZZER::buzz_off() {
	washMach_BUZZER_PRT_REG &= ~(uint16_t) washMach_BUZZER; //function to turn the buzzer off 
};

//==================== MOTOR_ON/OFF ================//
void MOTOR::motor_on() {
	washMach_MOTOR_CON_PRT_REG |= (uint16_t) washMach_MOTOR_CON; //function for turning on the motor
};

void MOTOR::motor_off() {
	washMach_MOTOR_CON_PRT_REG &= ~(uint16_t) washMach_MOTOR_CON; //function for turning off the motor
};

void MOTOR::motor_turn(int turning) {
	if (turning == ANTI_CLKWISE){
	washMach_MOTOR_DIREC_PRT_REG |= (uint16_t) washMach_MOTOR_DIREC;  //motor direction anti-clockwise
	}
	else{(turning = CLKWISE);
	washMach_MOTOR_DIREC_PRT_REG &= ~(uint16_t) washMach_MOTOR_DIREC;  //motor direction anti-clockwise
	}
};

//==========   DOOR OPEN/CLOSE  ============//

//Buzzer will sound if door is opened and when closed buzzer will not sound
void DOOR::isOpen(){
	port = (washMach_DOOR_OC_PRT_REG ) & washMach_DOOR_OC;  //checks if door is opened or closed
	if (port) {
		washMach_BUZZER_PRT_REG &= ~(uint16_t) washMach_BUZZER; //Buzzer on	
		}
	else {
		washMach_BUZZER_PRT_REG |= (uint16_t) washMach_BUZZER; //Buzzer off
	}
}


//============      BUTTONS    ===============//
void BUTTONS::resetInputLatch() {
	washMach_RESET_PRT_REG |= (uint16_t) washMach_RESET; 		//resets all input latches 
}

void BUTTONS::lowResetSwitch() {
	washMach_RESET_PRT_REG &= ~(uint16_t) washMach_RESET;		//LOW reset switches 
}



//void BUTTONS::cancel() {
//	washMach_CANCEL_PRT_REG &= ~(uint16_t) washMach_CANCEL;
//};

void BUTTONS::accept(){
	glphy = (washMach_ACCEPT_PRT_REG ) & washMach_ACCEPT ;  //checks if accept has been pressed 
	if (glphy) {
		washMach_MOTOR_CON_PRT_REG |= (uint16_t) washMach_MOTOR_CON;	 //Buzzer on	
		}
}

bool BUTTONS::Check(int pinID) {
			washMach_MOTOR_CON_PRT_REG |= (uint16_t) washMach_MOTOR_CON; //function for turning on the motor
			return (GPIOE->IDR) & pinID ;// PE10 programme select 3 (leftmost)	
};

	
//=============SELECTOR BUTTONS===============//	

void BUTTONS::latcher(){
	//washMach_SEVEN_SEG_A_PRT_REG |= (uint16_t)0x4000;
	washMach_RESET_PRT_REG |= (uint16_t)washMach_RESET;  // latcher buttons
}
void BUTTONS::resetlatch(){
	//washMach_SEVEN_SEG_A_PRT_REG &= ~(uint16_t)0x4000;  // restlatcher buttons
	washMach_RESET_PRT_REG &= ~(uint16_t)washMach_RESET;
}

void BUTTONS::left(int selector_L) {
if (selector_L == SELC)
	washMach_PROG_SEL_1_PRT_REG |= (uint16_t) washMach_PROG_SEL_1;		//Left most program selector button. If slector_L is true then execute, else clear.
else{
	CLEAR_PRT_REG &= ~(uint16_t) CLEAR;
	}
}
	
void BUTTONS::middle(int selector_M) {
if (selector_M == SELC)
	washMach_PROG_SEL_2_PRT_REG |= (uint16_t) washMach_PROG_SEL_2;		//middle program selector button. If slector_M is true then execute, else clear.
else{
	CLEAR_PRT_REG &= ~(uint16_t) CLEAR;	
}
}
	
void BUTTONS::right(int selector_R) {
	if (selector_R == SELC)
		washMach_PROG_SEL_3_PRT_REG |= (uint16_t) washMach_PROG_SEL_3;		//Right most program selector button. If slector_R is true then execute, else clear
	else{
		CLEAR_PRT_REG &= ~(uint16_t) CLEAR;	
	}
}


//============= 7_SEGMENT_DISPLAY =============//
// This list references the array present in hardwarelayer_map.h for the 7 seg display and steps through each number in turn. 
// 'NUM0' references the definition present in that file, allowing us to keep the file size and complexity down.
void SEVENSEG::seven_seg_set(int num)	{

	RESET;
	if (num == 0){
	NUM0;
	}
	if (num == 1){
	NUM1;
	}
	if (num == 2){
	NUM2;
	}
	if (num == 3){
	NUM3;
	}
	if (num == 4){
	NUM4;
	}
	if (num == 5){
	NUM5;
	}
	if (num == 6){
	NUM6;
	}
	if (num == 7){
	NUM7;
	}
	if (num == 8){
	NUM8;
	}
	if (num == 9){
	NUM9;	
	}
};
